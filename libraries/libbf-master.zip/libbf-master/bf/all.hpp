#ifndef BF_ALL_HPP
#define BF_ALL_HPP

#include "bf/bloom_filter/a2.hpp"
#include "bf/bloom_filter/basic.hpp"
#include "bf/bloom_filter/bitwise.hpp"
#include "bf/bloom_filter/counting.hpp"
#include "bf/bloom_filter/stable.hpp"

#endif
